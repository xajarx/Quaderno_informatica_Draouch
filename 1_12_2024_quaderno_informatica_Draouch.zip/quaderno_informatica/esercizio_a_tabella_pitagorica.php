<?php
$title = "Esercizio A: Tabella Pitagorica"; // il titolo della pagina come una variabile PHP
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Rende la pagina responsiva per dispositivi mobili -->
    <title><?php echo $title; ?></title> <!-- Inserisce il titolo nella scheda del browser -->
</head>
<body>
    <h1><?php echo $title; ?></h1> <!--titolo -->
    <table border="1"> <!-- Crea una tabella con bordi visibili -->
        <?php
        // Crea una tabella pitagorica
        for ($i = 1; $i <= 10; $i++) { // Loop esterno: itera attraverso le righe
            echo "<tr>"; // Inizia una nuova riga della tabella
            for ($j = 1; $j <= 10; $j++) { // Loop interno: itera attraverso le colonne
                echo "<td>" . $i * $j . "</td>"; // Calcola il prodotto e lo mostra in una cella della tabella
            }
            echo "</tr>"; // Chiude la riga della tabella
        }
        ?>
    </table>
    <br> <!-- Spazio tra la tabella e il bottone -->
    <button onclick="window.location.href='index.html';">Torna alla Home</button> 
    <!-- Bottone che reindirizza l'utente alla pagina 'index.html' -->
    <footer>
        <p>Studente: Hajar Draouch | Matricola: 123456 | Anno: 2024</p>
    </footer>
</body>
</html>
