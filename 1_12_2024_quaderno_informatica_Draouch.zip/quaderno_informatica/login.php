<?php
// Avvia la sessione
session_start();

// Variabile per contenere eventuali errori
$error = "";

// Controllo del metodo di richiesta
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recupera i valori inseriti nel form
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Controlla le credenziali
    if ($username === 'admin' && $password === 'password') {
        // Se le credenziali sono corrette, imposta la sessione
        $_SESSION['loggedin'] = true;
        // Reindirizza l'utente alla homepage (index.php)
        header('Location: index.php');
        exit;
    } else {
        // Se le credenziali sono errate, mostra un messaggio di errore
        $error = "Credenziali errate! Riprova.";
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <!-- Specifica la codifica dei caratteri e rende la pagina responsive -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title> <!-- Titolo della pagina -->
</head>
<body>
    <!-- Intestazione principale -->
    <h1>Richiesta credenziali per l'accesso all'area riservata</h1>

    <!-- Messaggio di errore mostrato se le credenziali sono errate -->
    <?php if (!empty($error)): ?>
        <p style="color: red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <!-- Form per l'inserimento di username e password -->
    <form method="POST" action="">
        <!-- Campo per l'username -->
        <label for="username">User name:</label>
        <input type="text" id="username" name="username" required>
        <br>
        <!-- Campo per la password -->
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <br>
        <!-- Bottone per inviare il form -->
        <button type="submit">Login</button>
    </form>
</body>
</html>
