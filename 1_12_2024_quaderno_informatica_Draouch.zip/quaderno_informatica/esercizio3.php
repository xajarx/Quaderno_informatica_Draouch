<?php
// titolo della pagina
$title = "Esercizio 3: Cicli in PHP";

// Contenuto descrittivo dell'esercizio
$content = "In questo esercizio, vediamo come usare i cicli in PHP per ripetere delle azioni.";

// Esempio di codice PHP come stringa
$code = "<?php\n  for (\$i = 1; \$i <= 5; \$i++) {\n    echo 'Numero: ' . \$i . '<br>';\n  }\n?>";
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <!-- Specifica il set di caratteri e rende la pagina responsive -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Titolo dinamico della pagina -->
    <title><?php echo $title; ?></title>
</head>
<body>
    <!-- Intestazione principale centrata -->
    <h1 style="text-align: center;">Quaderno di Informatica</h1>
    
    <!-- Sommario con stile semplice -->
    <h2 style="text-align: left; margin-left: 20px;">Sommario</h2>
    
    <!-- Titolo dell'esercizio -->
    <h1><?php echo $title; ?></h1>
    
    <!-- Contenuto descrittivo dell'esercizio -->
    <p><?php echo $content; ?></p>
    
    <!-- Sezione per mostrare il codice di esempio -->
    <h2>Codice di esempio:</h2>
    <!-- <pre><code> preserva la formattazione; htmlspecialchars impedisce l'esecuzione del codice -->
    <pre><code><?php echo htmlspecialchars($code); ?></code></pre>
    
    <!-- Spiegazione del codice -->
    <h2>Spiegazione:</h2>
    <p>
        Il codice sopra utilizza un ciclo <code>for</code> per stampare i numeri da 1 a 5.
        Ogni volta che il ciclo viene eseguito, la variabile <code>\$i</code> incrementa di 1
        fino a quando non supera 5.
    </p>

    <!-- Pulsante per tornare alla home page -->
    <br>
    <button onclick="window.location.href='index.html';">Torna alla Home</button>

    <!-- Footer con informazioni sullo studente -->
    <footer>
        <p>Studente: Hajar Draouch | Matricola: 123456 | Anno: 2024</p>
    </footer>
</body>
</html>
