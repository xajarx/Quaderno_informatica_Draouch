<?php
// Avvia la sessione per accedere ai dati attualmente salvati
session_start();

// Distrugge la sessione attuale, eliminando tutti i dati associati
session_destroy();

// Reindirizza l'utente alla homepage (o altra pagina desiderata)
header('Location: index.php');

// Interrompe l'esecuzione del resto dello script per garantire il reindirizzamento immediato
exit;
?>
