<!DOCTYPE html>
<html lang="it"> 
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Rende la pagina responsiva per dispositivi mobili -->
    <title><?php echo "Esercizio 4: Normalizzazione delle Tabelle"; ?></title> <!-- Titolo della pagina -->
</head>
<body>
    <!-- Intestazione principale della pagina -->
    <h1><?php echo "Esercizio 4: Normalizzazione delle Tabelle"; ?></h1> <!-- Titolo della pagina -->
    <p>
        In questo esercizio analizziamo la tabella <strong>Voli</strong>, determinando le dipendenze funzionali,
        applicando le procedure di normalizzazione fino alla 3NF e verificando se è anche in BCNF.
    </p>

    <!-- Sezione: Tabella Originale -->
    <h2>Tabella Originale</h2>
    <table border="1" cellspacing="0" cellpadding="5"> <!-- Tabella con bordi, spazi tra celle e margini -->
        <tr>
            <!-- Intestazioni delle colonne -->
            <th>ora_volo</th>
            <th>tratta</th>
            <th>partenza</th>
            <th>arrivo</th>
            <th>aereo</th>
            <th>posti</th>
        </tr>
        <?php
        // Dati della tabella originale salvati in un array
        $voli = [
            ['07.00', 'T1', 'Milano', 'Napoli', 'A01', 90],
            ['07.00', 'T2', 'Roma', 'Milano', 'A05', 80],
            ['12.30', 'T1', 'Milano', 'Napoli', 'A02', 70],
            ['10.00', 'T2', 'Roma', 'Milano', 'A01', 90],
            ['10.00', 'T3', 'Roma', 'Napoli', 'A07', 85],
            ['11.30', 'T1', 'Milano', 'Napoli', 'A05', 80]
        ];

        // Ciclo che genera le righe della tabella in HTML
        foreach ($voli as $volo) {
            echo "<tr>"; // Inizio riga
            foreach ($volo as $colonna) { // Itera ogni valore nella riga
                echo "<td>$colonna</td>"; // Crea una cella per ogni valore
            }
            echo "</tr>"; // Fine riga
        }
        ?>
    </table>
    
    <!-- Sezione: Dipendenze Funzionali -->
    <h2>Dipendenze Funzionali</h2>
    <ul>
        <!-- Elenco delle dipendenze funzionali -->
        <li><strong>tratta → partenza</strong> (ogni tratta ha un'unica partenza e un unico arrivo)</li>
        <li><strong>tratta → arrivo</strong></li>
        <li><strong>ora_volo, tratta → aereo</strong> (ad ogni volo è associato un aereo)</li>
        <li><strong>aereo → posti</strong> (ogni aereo ha una sua capienza massima)</li>
    </ul>

    <!-- Sezione: Seconda Forma Normale (2NF) -->
    <h2>Seconda Forma Normale (2NF)</h2>
    <p>
        La tabella originale <strong>Voli</strong> non è in 2FN perché partenza e arrivo dipendono solo da tratta.
        Dividiamo la tabella in:
    </p>
    <h3>Voli2</h3>
    <table border="1" cellspacing="0" cellpadding="5">
        <tr>
            <!-- Intestazioni della nuova tabella -->
            <th>ora_volo</th>
            <th>tratta</th>
            <th>aereo</th>
            <th>posti</th>
        </tr>
        <?php
        // Dati della tabella Voli2 salvati in un array
        $voli2 = [
            ['07.00', 'T1', 'A01', 90],
            ['07.00', 'T2', 'A05', 80],
            ['12.30', 'T1', 'A02', 70],
            ['10.00', 'T2', 'A01', 90],
            ['10.00', 'T3', 'A07', 85],
            ['11.30', 'T1', 'A05', 80]
        ];

        // Ciclo che genera le righe della tabella Voli2
        foreach ($voli2 as $volo) {
            echo "<tr>";
            foreach ($volo as $colonna) {
                echo "<td>$colonna</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>

    <h3>Tratte</h3>
    <table border="1" cellspacing="0" cellpadding="5">
        <tr>
            <!-- Intestazioni della tabella Tratte -->
            <th>tratta</th>
            <th>partenza</th>
            <th>arrivo</th>
        </tr>
        <?php
        // Dati della tabella Tratte salvati in un array
        $tratte = [
            ['T1', 'Milano', 'Napoli'],
            ['T2', 'Roma', 'Milano'],
            ['T3', 'Roma', 'Napoli']
        ];

        // Ciclo che genera le righe della tabella Tratte
        foreach ($tratte as $tratta) { // itera su ogni elemento dell'array $tratte
            echo "<tr>"; //nuova riga HTML 
            
            foreach ($tratta as $colonna) { // itera su ogni valore all'interno della riga $tratta
                echo "<td>$colonna</td>"; // Stampa una cella della tabella HTML (<td>) con il valore corrente
            }
            
            echo "</tr>"; 
        }
        ?>
    </table>

    <!-- Conclusione della normalizzazione -->
    <h2>Conclusione</h2>
    <p>
        Lo schema ottenuto è anche in BCNF poiché tutte le tabelle soddisfano i requisiti di 3NF e ogni dipendenza funzionale
        ha il determinante come superchiave.
    </p>

    <br>
    <button onclick="window.location.href='index.html';">Torna alla Home</button>

    <!-- Footer dinamico -->
    <footer>
        <p>Studente: <?php echo "Hajar Draouch"; ?> | Matricola: <?php echo "123456"; ?> | Anno: <?php echo "2024"; ?></p>
    </footer>
</body>
</html>
