<?php
// Una dettagliata introduzione a PHP
echo "<h1>Benvenuto nel mondo di PHP!</h1>";

// Introduzione
echo "<p><strong>PHP</strong> (acronimo ricorsivo di 'PHP: Hypertext Preprocessor') è un linguaggio di scripting lato server ampiamente utilizzato per lo sviluppo web. È facile da imparare, flessibile, e offre potenti funzionalità per creare applicazioni dinamiche e interattive.</p>";

// Come funziona PHP
echo "<h2>Come funziona PHP?</h2>";
echo "<p>Quando un utente accede a una pagina scritta in PHP, il server web processa il codice PHP e invia il risultato HTML all'utente. PHP viene eseguito sul server, quindi l'utente non vede il codice sorgente.</p>";

// Un po' di storia
echo "<h2>Breve storia di PHP</h2>";
echo "<ul>";
echo "<li><strong>1994:</strong> Creato da Rasmus Lerdorf come una serie di script CGI.</li>";
echo "<li><strong>1997:</strong> PHP/FI diventa PHP 3, la prima versione ufficiale.</li>";
echo "<li><strong>2004:</strong> Viene rilasciato PHP 5, con il supporto completo alla programmazione orientata agli oggetti.</li>";
echo "<li><strong>2020:</strong> Lanciato PHP 8, con grandi miglioramenti nelle prestazioni grazie a JIT (Just-In-Time) Compiler.</li>";
echo "</ul>";

// Sintassi base di PHP
echo "<h2>Sintassi base di PHP</h2>";
echo "<p>Il codice PHP è racchiuso tra tag speciali <code>&lt;?php</code> e <code>?&gt;</code>. Ecco un esempio:</p>";

echo "<pre>";
echo htmlspecialchars('<?php
// Dichiarazione di una variabile
$nome = "PHP";

// Output del contenuto della variabile
echo "Benvenuto in " . $nome . "!";
?>');
echo "</pre>";

// Concetti fondamentali
echo "<h2>Concetti fondamentali in PHP</h2>";
echo "<ul>";
echo "<li><strong>Variabili:</strong> Usate per memorizzare dati. In PHP, le variabili iniziano con il simbolo <code>$</code>.</li>";
echo "<li><strong>Tipi di dati:</strong> PHP supporta vari tipi di dati, come stringhe, numeri interi, numeri decimali, array e oggetti.</li>";
echo "<li><strong>Condizioni:</strong> Strutture come <code>if</code>, <code>else</code>, e <code>switch</code> aiutano a prendere decisioni basate sui dati.</li>";
echo "<li><strong>Cicli:</strong> Utilizzati per eseguire lo stesso blocco di codice più volte (<code>for</code>, <code>while</code>, <code>foreach</code>).</li>";
echo "<li><strong>Funzioni:</strong> Blocchi di codice riutilizzabili che eseguono compiti specifici.</li>";
echo "</ul>";

// Esempio pratico
echo "<h2>Esempio pratico: Calcolo della somma</h2>";

echo "<p>Ecco un esempio di un piccolo script che calcola la somma di due numeri:</p>";

echo "<pre>";
echo htmlspecialchars('<?php
// Numeri da sommare
$num1 = 5;
$num2 = 10;

// Somma dei numeri
$somma = $num1 + $num2;

// Mostra il risultato
echo "La somma di $num1 e $num2 è: $somma";
?>');
echo "</pre>";

// Esecuzione dell'esempio
echo "<h2>Risultato dell'esempio:</h2>";
$num1 = 5;
$num2 = 10;
$somma = $num1 + $num2;
echo "La somma di $num1 e $num2 è: $somma";

// Conclusione
echo "<h2>Conclusione</h2>";
echo "<p>PHP è un linguaggio versatile e potente, perfetto per sviluppatori web di tutti i livelli. Con un po' di pratica, puoi usarlo per creare tutto, dai semplici siti statici alle complesse applicazioni web.</p>";
?>
