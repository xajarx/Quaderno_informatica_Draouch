<?php
// titolo della pagina
$title = "Esercizio C: Triangoli di Asterischi";
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <!-- Specifica il set di caratteri e rende la pagina responsive -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Stampa dinamicamente il titolo della pagina -->
    <title><?php echo $title; ?></title>
    <!-- Applica uno stile monospace per allineare meglio gli asterischi -->
    <style>body { font-family: monospace; }</style>
</head>
<body>
    <!-- Mostra il titolo della pagina come intestazione -->
    <h1><?php echo $title; ?></h1>

    <?php
    // Sezione (a): Triangolo crescente
    echo "<h2>(a) Crescente</h2>";
    for ($i = 1; $i <= 10; $i++) { // Ciclo per righe da 1 a 10
        // Ripete l'asterisco $i volte e aggiunge una nuova riga
        echo str_repeat("*", $i) . "<br>";
    }

    // Sezione (b): Triangolo decrescente
    echo "<h2>(b) Decrescente</h2>";
    for ($i = 10; $i >= 1; $i--) { // Ciclo per righe da 10 a 1
        // Ripete l'asterisco $i volte e aggiunge una nuova riga
        echo str_repeat("*", $i) . "<br>";
    }

    // Sezione (c): Triangolo specchiato decrescente
    echo "<h2>(c) Specchiato Decrescente</h2>";
    for ($i = 10; $i >= 1; $i--) { // Ciclo per righe da 10 a 1
        // Ripete spazi vuoti (10 - $i) volte e poi asterischi $i volte
        echo str_repeat("&nbsp;", 10 - $i) . str_repeat("*", $i) . "<br>";
    }

    // Sezione (d): Triangolo specchiato crescente
    echo "<h2>(d) Specchiato Crescente</h2>";
    for ($i = 1; $i <= 10; $i++) { // Ciclo per righe da 1 a 10
        // Ripete spazi vuoti (10 - $i) volte e poi asterischi $i volte
        echo str_repeat("&nbsp;", 10 - $i) . str_repeat("*", $i) . "<br>";
    }
    ?>

    <br>
    <!-- Pulsante per tornare alla pagina principale -->
    <button onclick="window.location.href='index.html';">Torna alla Home</button>
    <footer>
        <!-- Informazioni sullo studente -->
        <p>Studente: Hajar Draouch | Matricola: 123456 | Anno: 2024</p>
    </footer>
</body>
</html>
