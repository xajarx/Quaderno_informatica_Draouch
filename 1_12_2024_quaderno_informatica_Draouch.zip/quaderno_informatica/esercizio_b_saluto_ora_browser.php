<?php
// titolo della pagina
$title = "Esercizio B: Saluto in Base all'Ora";

// nome dell'utente
$nome = "Prof Torsello";

// Ottiene l'ora corrente in formato 24 ore
$ora = date("H");

// Determina il saluto in base all'orario corrente
$saluto = ($ora >= 8 && $ora < 12) ? "Buongiorno" : (($ora >= 12 && $ora < 20) ? "Buonasera" : "Buonanotte");

// Ottiene il browser usato dall'utente tramite l'header HTTP_USER_AGENT
$browser = $_SERVER['HTTP_USER_AGENT'];
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <!-- Specifica il set di caratteri e rende la pagina responsive -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Stampa il titolo della pagina dinamicamente -->
    <title><?php echo $title; ?></title>
</head>
<body>
    <!-- Stampa il saluto personalizzato concatenando il saluto e il nome -->
    <h1><?php echo $saluto . " " . $nome; ?></h1>
    <!-- Testo statico di benvenuto -->
    <p>Benvenuta nella mia prima pagina PHP.</p>
    <!-- Mostra il browser usato dall'utente -->
    <p>Stai usando il browser: <?php echo $browser; ?></p>
    <br>
    <!-- Pulsante che reindirizza l'utente alla home page -->
    <button onclick="window.location.href='index.html';">Torna alla Home</button>
    <footer>
        <!-- Informazioni sullo studente -->
        <p>Studente: Hajar Draouch | Matricola: 123456 | Anno: 2024</p>
    </footer>
</body>
</html>
