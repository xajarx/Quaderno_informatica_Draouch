<?php
//titolo della pagina
$title = "Esercizio 2: Strutture Condizionali in PHP";

// Contenuto descrittivo dell'esercizio
$content = "In questo esercizio, vediamo come usare le strutture condizionali in PHP.";

// Esempio di codice PHP come stringa
$code = "<?php\n  \$numero = 5;\n  if (\$numero > 10) {\n    echo 'Il numero è maggiore di 10';\n  } else {\n    echo 'Il numero è minore o uguale a 10';\n  }\n?>";
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <!-- Specifica la codifica dei caratteri e rende la pagina responsive -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Titolo della pagina generato dinamicamente -->
    <title><?php echo $title; ?></title>
</head>
<body>
    <!-- Intestazione principale centrata -->
    <h1 style="text-align: center;">Quaderno di Informatica</h1>
    
    <!-- Sommario con stile aggiuntivo -->
    <h2 style="text-align: left; margin-left: 20px;">Sommario</h2>
    
    <!-- Titolo dell'esercizio -->
    <h1><?php echo $title; ?></h1>
    
    <!-- Descrizione del contenuto -->
    <p><?php echo $content; ?></p>
    
    <!-- Sezione per mostrare il codice di esempio -->
    <h2>Codice di esempio:</h2>
    <!-- <pre><code> permette di mostrare il codice formattato, htmlspecialchars impedisce l'esecuzione del codice -->
    <pre><code><?php echo htmlspecialchars($code); ?></code></pre>
    
    <!-- Spiegazione del codice -->
    <h2>Spiegazione:</h2>
    <p>
        Il codice sopra utilizza una struttura condizionale <code>if-else</code> per verificare se il valore della variabile 
        <code>\$numero</code> è maggiore di 10. Se vero, stampa un messaggio, altrimenti ne stampa un altro.
    </p>

    <!-- Pulsante per tornare alla home -->
    <br>
    <button onclick="window.location.href='index.html';">Torna alla Home</button>

    <!-- Footer con informazioni sullo studente -->
    <footer>
        <p>Studente: Hajar Draouch | Matricola: 123456 | Anno: 2024</p>
    </footer>
</body>
</html>
